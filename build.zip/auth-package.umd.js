(function(n,r){typeof exports=="object"&&typeof module<"u"?r(exports,require("react")):typeof define=="function"&&define.amd?define(["exports","react"],r):(n=typeof globalThis<"u"?globalThis:n||self,r(n.AuthPackage={}))})(this,function(n){"use strict";var r={exports:{}},i={};/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var s;function f(){if(s)return i;s=1;var R=Symbol.for("react.transitional.element"),v=Symbol.for("react.fragment");function x(c,e,t){var o=null;if(t!==void 0&&(o=""+t),e.key!==void 0&&(o=""+e.key),"key"in e){t={};for(var u in e)u!=="key"&&(t[u]=e[u])}else t=e;return e=t.ref,{$$typeof:R,type:c,key:o,ref:e!==void 0?e:null,props:t}}return i.Fragment=v,i.jsx=x,i.jsxs=x,i}var d;function a(){return d||(d=1,r.exports=f()),r.exports}var l=a();const p=()=>l.jsx("div",{children:"Login From"});n.LoginForm=p,Object.defineProperty(n,Symbol.toStringTag,{value:"Module"})});
