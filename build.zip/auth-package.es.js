import "react";
var i = { exports: {} }, e = {};
/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var s;
function d() {
  if (s) return e;
  s = 1;
  var R = Symbol.for("react.transitional.element"), v = Symbol.for("react.fragment");
  function o(a, r, t) {
    var n = null;
    if (t !== void 0 && (n = "" + t), r.key !== void 0 && (n = "" + r.key), "key" in r) {
      t = {};
      for (var u in r)
        u !== "key" && (t[u] = r[u]);
    } else t = r;
    return r = t.ref, {
      $$typeof: R,
      type: a,
      key: n,
      ref: r !== void 0 ? r : null,
      props: t
    };
  }
  return e.Fragment = v, e.jsx = o, e.jsxs = o, e;
}
var x;
function l() {
  return x || (x = 1, i.exports = d()), i.exports;
}
var p = l();
const m = () => /* @__PURE__ */ p.jsx("div", { children: "Login From" });
export {
  m as LoginForm
};
